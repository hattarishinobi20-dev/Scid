namespace Supercell.Laser.Server.SCID
{
    using MySql.Data.MySqlClient;
    using Newtonsoft.Json;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Settings;
    using System.Text;
    using System.Threading;

    public static class SCIDBase
    {
        private static long AccountsMaxId;
        private static string ConnectionString;

        public static void Init(string user, string password)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = Configuration.Instance.MysqlHost;
            builder.Port = (uint)Configuration.Instance.MysqlPort;
            builder.UserID = user;
            builder.Password = password;
            builder.SslMode = MySqlSslMode.Required;
            builder.Database = Configuration.Instance.MysqlDatabase;
            builder.CharacterSet = "utf8mb4";

            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                DefaultValueHandling = DefaultValueHandling.Ignore,
                NullValueHandling = NullValueHandling.Ignore
            };

            ConnectionString = builder.ToString();

            AccountsMaxId = GetMaxAccountId();
        }

        public static long GetMaxAccountId()
        {
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using MySqlCommand command = new MySqlCommand("SELECT coalesce(MAX(Id), 0) FROM SCIDaccounts", connection);
            return Convert.ToInt64(command.ExecuteScalar());
        }

        public static void Create(SCIDAccount account)
        {
            if (account == null) return;

            account.AccountId = Interlocked.Increment(ref AccountsMaxId);
            string json = JsonConvert.SerializeObject(account);

            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using MySqlCommand command = new MySqlCommand("INSERT INTO SCIDaccounts (`ScidToken`, `Data`) VALUES (@token, @data)", connection);
            command.Parameters?.AddWithValue("@token", account.ScidToken);
            command.Parameters?.AddWithValue("@data", json);
            command.ExecuteNonQuery();
        }

        public static void Save(SCIDAccount account)
        {
            if (account == null) return;

            string json = JsonConvert.SerializeObject(account);

            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using MySqlCommand command = new MySqlCommand("UPDATE SCIDaccounts SET `Data` = @data WHERE `ScidToken` = @token", connection);
            command.Parameters?.AddWithValue("@token", account.ScidToken);
            command.Parameters?.AddWithValue("@data", json);
            command.ExecuteNonQuery();
        }

        private static SCIDAccount Load(string token)
        {
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using MySqlCommand command = new MySqlCommand("SELECT `Data` FROM SCIDaccounts WHERE `ScidToken` = @token", connection);
            command.Parameters?.AddWithValue("@token", token);
            using MySqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
                return Deserialize(reader);

            return null;
        }

        public static SCIDAccount LoadByToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
                return null;

            token = token.Trim().TrimEnd('\0');

            SCIDAccount account = Load(token);
            if (account != null)
                return account;

            if (token.Contains('.'))
                return null;

            string decodedToken = TryDecodeBase64Url(token);
            return decodedToken == null ? null : Load(decodedToken);
        }

        private static string TryDecodeBase64Url(string value)
        {
            try
            {
                string base64 = value.Replace('-', '+').Replace('_', '/');
                base64 = base64.PadRight((base64.Length + 3) / 4 * 4, '=');
                return Encoding.UTF8.GetString(Convert.FromBase64String(base64)).TrimEnd('\0');
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static SCIDAccount LoadByIdentity(string identity)
        {
            return LoadFirst(account => string.Equals(account.Identity, identity, StringComparison.OrdinalIgnoreCase));
        }

        public static SCIDAccount LoadByScid(string scid)
        {
            return LoadFirst(account => string.Equals(account.Scid, scid, StringComparison.Ordinal));
        }

        private static SCIDAccount LoadFirst(Func<SCIDAccount, bool> predicate)
        {
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using MySqlCommand command = new MySqlCommand("SELECT `Data` FROM SCIDaccounts", connection);
            using MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                SCIDAccount account = Deserialize(reader);
                if (account != null && predicate(account))
                    return account;
            }

            return null;
        }

        private static SCIDAccount Deserialize(MySqlDataReader reader)
        {
            try
            {
                object value = reader["Data"];
                if (value == null || value == DBNull.Value)
                    return null;
                return JsonConvert.DeserializeObject<SCIDAccount>(Convert.ToString(value));
            }
            catch (JsonException exception)
            {
                // One corrupt row must not make every SCID request fail.
                SCIDStart.Log($"ignoring malformed SCID account data: {exception.Message}");
                return null;
            }
        }

        public static void Delete(string token)
        {
            using MySqlConnection connection = new(ConnectionString);
            connection.Open();
            using MySqlCommand command = new("DELETE FROM SCIDaccounts WHERE ScidToken = @token", connection);
            command.Parameters?.AddWithValue("@token", token);
            command.ExecuteNonQuery();
        }
    }
}
