using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileProviders;

namespace Supercell.Laser.Server.SCID
{
    internal static class SCIDAssets
    {
        private const string ManifestName = "AssetManifest.json";

        public static void Register(WebApplication app)
        {
            string root = Path.Combine(AppContext.BaseDirectory, "SCID", "Assets");
            if (!Directory.Exists(root)) return;

            PhysicalFileProvider provider = new(root);
            app.Lifetime.ApplicationStopped.Register(provider.Dispose);
            app.UseStaticFiles(CreateOptions(provider, PathString.Empty));
            app.UseStaticFiles(CreateOptions(provider, new PathString("/assets")));
            // AssetManifest.json addresses files below the logical
            // `RemoteAssets/` prefix, while the extracted bundle stores the
            // iOS/Android/Localizations directories directly under Assets.
            // Expose both URL forms used by different client revisions.
            app.UseStaticFiles(CreateOptions(provider, new PathString("/RemoteAssets")));
            app.UseStaticFiles(CreateOptions(provider, new PathString("/assets/RemoteAssets")));
        }

        private static StaticFileOptions CreateOptions(IFileProvider provider, PathString requestPath)
        {
            return new StaticFileOptions
            {
                FileProvider = provider,
                RequestPath = requestPath,
                ServeUnknownFileTypes = true,
                DefaultContentType = "application/octet-stream",
                OnPrepareResponse = context =>
                {
                    HttpResponse response = context.Context.Response;
                    response.Headers["X-Content-Type-Options"] = "nosniff";
                    response.Headers.CacheControl = string.Equals(
                        context.File.Name,
                        ManifestName,
                        StringComparison.OrdinalIgnoreCase)
                            ? "no-cache"
                            : "public, max-age=86400";
                }
            };
        }
    }
}
