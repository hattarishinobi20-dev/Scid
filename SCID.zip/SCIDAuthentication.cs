namespace Supercell.Laser.Server.SCID
{
    using Microsoft.AspNetCore.Http;
    using Supercell.Laser.Server.Database.Models;

    internal static class SCIDAuthentication
    {
        public static SCIDAccount FromBody(Dictionary<string, string> body)
        {
            if (body == null)
                return null;

            // Different Supercell ID client revisions use different casing
            // and field names.  Read the standard form first, then the
            // aliases used by older web and mobile clients.
            string token = GetToken(body);
            return SCIDBase.LoadByToken(token);
        }

        public static SCIDAccount FromRequest(HttpRequest request, Dictionary<string, string> body)
        {
            string token = GetToken(body);
            if (!string.IsNullOrEmpty(token))
                return SCIDBase.LoadByToken(token);

            if (request == null)
                return null;

            string authorization = request.Headers.Authorization.FirstOrDefault();
            return authorization?.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase) == true
                ? SCIDBase.LoadByToken(authorization[7..].Trim())
                : null;
        }

        private static string GetToken(Dictionary<string, string> body)
        {
            if (body == null)
                return null;

            foreach (string key in new[] { "scid_token", "scidToken", "access_token", "token" })
            {
                if (body.TryGetValue(key, out string token) && !string.IsNullOrWhiteSpace(token))
                    return token.Trim();
            }

            return null;
        }
    }
}
